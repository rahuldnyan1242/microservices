package com.user.service.USMicrovservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsMicrovservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsMicrovservicesApplication.class, args);
	}

}

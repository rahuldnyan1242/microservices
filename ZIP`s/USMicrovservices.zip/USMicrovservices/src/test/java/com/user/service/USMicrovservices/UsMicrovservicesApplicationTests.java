package com.user.service.USMicrovservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsMicrovservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}

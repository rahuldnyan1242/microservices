package com.hotel.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}

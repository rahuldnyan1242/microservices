package com.user.service.TestUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
